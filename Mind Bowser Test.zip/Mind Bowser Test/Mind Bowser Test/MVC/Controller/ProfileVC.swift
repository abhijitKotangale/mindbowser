//
//  ProfileVC.swift
//  Mind Bowser Test
//
//  Created by Mac on 03/06/21.
//

import UIKit
import TwitterKit

class ProfileVC: BaseVC {

    //Outlets
    @IBOutlet weak var imgBaner: UIImageView!
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var btnFollowers: UIButton!
    @IBOutlet weak var btnFollowing: UIButton!
    
    var userid = UserDefaults.standard.string(forKey: "user_id")
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Load user data
        self.loadContents()
    }
    
    //MARK: Load User Contents
    func loadContents() {
        
        let twitterClient = TWTRAPIClient(userID: userid)
        twitterClient.loadUser(withID: (userid)!, completion: { (user, error) in
            print(user!.profileImageLargeURL)
            let url = URL(string: user!.profileImageLargeURL)
            let data = try? Data(contentsOf: url!)
            
            DispatchQueue.main.async {
                if let imageData = data {
                    self.imgProfile.image = UIImage(data: imageData)
                }
            }
        })
        
        self.lblUsername.text = UserDefaults.standard.string(forKey: "username")
        self.lblEmail.text = UserDefaults.standard.string(forKey: "email")
        
    }
    
    

} //MARK: End Main Class
