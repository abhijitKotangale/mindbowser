//
//  LoginVC.swift
//  Mind Bowser Test
//
//  Created by Mac on 03/06/21.
//

import UIKit
import TwitterKit
import FirebaseAuth

class LoginVC: UIViewController {

    var twitterSession: TWTRSession?
    var name:String? = ""
    var username:String? = ""
    var email:String? = ""
    var profileImage:UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    //MARK: Login Controller Action
    @IBAction func btnTwitterLoginAction(_ sender: UIButton) {
        TWTRTwitter.sharedInstance().logIn { (session, err) in
            if let err = err {
                print("Error =>\(err)")
                return
            }
            
            self.dismiss(animated: true, completion: nil)
            guard let session = session else {return}
            self.twitterSession = session
            self.signIntoFirebaseWithTwitter()
        }
    }
    
    func signIntoFirebaseWithTwitter(){
        guard let twitterSession = twitterSession else{return}
        let credential = TwitterAuthProvider.credential(withToken: twitterSession.authToken, secret: twitterSession.authTokenSecret)
        Auth.auth().signIn(with: credential) { (user, err) in
            if let err = err {
                print("Error =>\(err)")
                return
            }
            
            UserDefaults.standard.setValue(twitterSession.userID, forKey: "user_id")
            UserDefaults.standard.setValue(twitterSession.userName, forKey: "username")
            
            let client = TWTRAPIClient.withCurrentUser()
            client.requestEmail { email, error in
                if (email != nil) {
                    let recivedEmailID = email ?? ""
                    UserDefaults.standard.setValue(recivedEmailID, forKey: "email")
                    //Set Root Controller
                    sceneDelegate.setProfileScreenRoot()
                }else {
                    print("error--: \(String(describing: error?.localizedDescription))");
                    //Set Root Controller
                    sceneDelegate.setProfileScreenRoot()
                }
            }
            
        }
    }
    
    
} //MARK: End Main Class

