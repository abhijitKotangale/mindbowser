//
//  Genral.swift
//  Mind Bowser Test
//
//  Created by Mac on 03/06/21.
//

import Foundation
import UIKit

//MARK: Global Varible
let sceneDelegate = UIApplication.shared.connectedScenes.first!.delegate as! SceneDelegate
var navController = UINavigationController()
let consumerKey = "Sh4JYw4aQ773emLJTL9zlFFF2"
let consumerSecrete = "KYZk6x2O0HO8e1ClUyqDDMjXOnYJhjwHBXrY4PJ6M7OFBxkE7z"

//MARK: Storyboard List
let main_storyboard = UIStoryboard(name: "Main", bundle: nil)
